{-# LANGUAGE PartialTypeSignatures , FlexibleContexts, Strict, DeriveGeneric, StandaloneDeriving #-}

module Instantiation.BinaryElf (elf_read_file) where

import Base

import Generic.Binary

import Data.Elf
import Data.Symbol

import qualified Data.Map as M
import qualified Data.Set as S
import qualified Data.IntMap as IM
import qualified Data.IntSet as IS
import Data.Word 
import Data.List
import Data.Bits
import Data.Maybe (fromJust)
import Data.List.Extra (firstJust)
import qualified Data.ByteString as BS
import GHC.Generics
import qualified Data.Serialize as Cereal hiding (get,put)
import qualified Data.Text                  as T
import qualified Data.Text.Encoding         as T

import Debug.Trace

deriving instance Generic ElfMachine
deriving instance Generic ElfSegmentType
deriving instance Generic ElfSegmentFlag
deriving instance Generic ElfSegment
deriving instance Generic ElfType
deriving instance Generic ElfOSABI
deriving instance Generic ElfClass
deriving instance Generic ElfData
deriving instance Generic ElfSectionFlags
deriving instance Generic ElfSectionType
deriving instance Generic ElfSection
deriving instance Generic Elf

instance Cereal.Serialize ElfMachine
instance Cereal.Serialize ElfSegmentType
instance Cereal.Serialize ElfSegmentFlag
instance Cereal.Serialize ElfSegment
instance Cereal.Serialize ElfType
instance Cereal.Serialize ElfOSABI
instance Cereal.Serialize ElfClass
instance Cereal.Serialize ElfData
instance Cereal.Serialize ElfSectionFlags
instance Cereal.Serialize ElfSectionType
instance Cereal.Serialize ElfSection
instance Cereal.Serialize Elf




-- | Overview of sections with read only data.
sections_ro_data = [
   ("",".text"),
   ("",".init"),
   ("",".fini"),
   ("",".rodata"),
   ("",".plt"),
   ("",".plt.got"),
   ("",".plt.sec"),
   ("",".data.rel.ro"),
   ("",".init_array"),
   ("",".fini_array")
 ]

sections_data = [
   ("",".data")
 ]

sections_bss = [
   ("",".bss")
 ]


sections_text = [
   ("",".text")
 ]



isRelevantElfSection section = ("",elfSectionName section) `elem` sections_ro_data ++ sections_data ++ sections_bss

isAllocated section = SHF_ALLOC `elem` elfSectionFlags section



-- reading bytes from sections. 
read_bytes_section a si section = BS.unpack $ BS.take si $ BS.drop (fromIntegral $ a - elfSectionAddr section) $ elfSectionData section

contains_address a si section = 
  let a0  = elfSectionAddr section
      si0 = elfSectionSize section in
    a0 <= a && a < a0 + si0

elf_read_ro_data :: Elf -> Word64 -> Int -> Maybe [Word8]
elf_read_ro_data elf a si =
  case filter isRelevant $ filter (contains_address a si) $ elfSections elf of
    [] -> Nothing
    [section] -> Just $ read_bytes_section a si section
 where
  isRelevant section
    |  ("",elfSectionName section) `elem` sections_ro_data = True
    | otherwise = False

elf_read_data :: Elf -> Word64 -> Int -> Maybe [Word8]
elf_read_data elf a si =
  case filter isBss $ filter (contains_address a si) $ elfSections elf of
    [section] -> Just $ replicate si 0
    [] -> try_read_data
 where 
  try_read_data =
    case filter isData $ filter (contains_address a si) $ elfSections elf of
      [] -> Nothing
      [section] -> Just $ read_bytes_section a si section

  isData section 
    | ("",elfSectionName section) `elem` sections_data = True
    | otherwise = False
  isBss section 
    | ("",elfSectionName section) `elem` sections_bss = True
    | otherwise = False



elf_get_relocs elf = S.fromList $ mk_relocs
 where
  -- go through all relocations
  mk_relocs = concatMap mk_reloc $ parseRelocations elf
  
  mk_reloc sec = concatMap (try_mk_reloc sec) (elfRelSectRelocations sec)

  try_mk_reloc sec reloc
   | elfRelType reloc == 8 =
     -- R_X86_64_RELATIVE
     -- The SymAddend provides the relocation address
     case elfRelSymAddend reloc of
       Nothing     -> [Relocation (fromIntegral $ elfRelOffset reloc) 0] -- TODO implicit addend?
       Just addend -> [Relocation (fromIntegral $ elfRelOffset reloc) (fromIntegral $ addend)]
   | otherwise = []


elf_get_symbol_table elf = SymbolTable mk_symbols mk_globals
 where
  mk_symbols = IM.fromList $ filter ((/=) "" . symbol_to_name . snd) $ symbols_from_ELF_symbol_tables ++ symbols_from_relocations

  mk_globals = S.fromList $ filter ((/=) "") $ map (get_string_from_steName . steName) $ filter isGlobalAndInternallyDefined $ concat $ parseSymbolTables elf

  isGlobalAndInternallyDefined sym_entry = steIndex sym_entry /= SHNUndef && steBind sym_entry == STBGlobal




  -- go through all relocations
  symbols_from_relocations = concatMap mk_symbol_table_for_reloc_section $ parseRelocations elf
  
  mk_symbol_table_for_reloc_section sec = concatMap (try_mk_symbol_entry sec) (elfRelSectRelocations sec)

  try_mk_symbol_entry sec reloc
    | elfRelType reloc == 7 =
      -- R_X86_64_JUMP_SLOT
      -- the RelSymbol provides an index into a lookup table that contains the name of the symbol
      [(fromIntegral $ elfRelOffset reloc, (uncurry PointerToLabel) $ get_name_and_inex_from_reloc sec reloc)]
    | elfRelType reloc == 6 =
      -- R_X86_64_GLOB_DAT, objects
      -- the RelSymbol provides an index into a lookup table that contains the name of the symbol
      let symbol_table_entry      = (elfRelSectSymbolTable sec) !! (fromIntegral $ elfRelSymbol reloc)
          name_of_reloc_trgt      = get_name_and_inex_from_sym_entry $ symbol_table_entry
          symb_type_of_reloc_trgt = steType $ symbol_table_entry
          reloc_address           = fromIntegral $ elfRelOffset reloc in
        if symb_type_of_reloc_trgt `elem` [STTObject,STTCommon] then
          let symbol_table_entry = (elfRelSectSymbolTable sec) !! (fromIntegral $ elfRelSymbol reloc)
              bind               = steBind symbol_table_entry
              value              = steValue symbol_table_entry in
            if any (\sec -> any (\reloc -> elfRelOffset reloc == value) $ elfRelSectRelocations sec) $ parseRelocations elf then
              [(reloc_address, (Relocated_ResolvedObject (fst name_of_reloc_trgt) value))]
            else
              [(reloc_address, (uncurry PointerToObject) name_of_reloc_trgt)]
        else 
          [(reloc_address, (uncurry PointerToLabel) name_of_reloc_trgt)]
   | elfRelType reloc == 5 =
      -- R_X86_64_COPY
      -- the RelSymbol provides an index into a lookup table that contains the name of the symbol
      [(fromIntegral $ elfRelOffset reloc, AddressOfObject (fst $ get_name_and_inex_from_reloc sec reloc) True)]
   | elfRelType reloc == 1 =
      -- R_X86_64_64
      -- the RelSymbol provides an index into a lookup table that contains the name of the symbol
      -- RelSymAddend should be zero
      let symbol_table_entry      = (elfRelSectSymbolTable sec) !! (fromIntegral $ elfRelSymbol reloc)
          name_of_reloc_trgt      = get_name_and_inex_from_sym_entry symbol_table_entry
          symb_type_of_reloc_trgt = steType $ symbol_table_entry
          reloc_address           = fromIntegral $ elfRelOffset reloc in
        if symb_type_of_reloc_trgt == STTFunc then
          [(reloc_address, (uncurry PointerToLabel) name_of_reloc_trgt)]
        else
          error $ show (reloc,symbol_table_entry,symb_type_of_reloc_trgt) -- TODO very likely this is exactly the same as elfRelType reloc == 6
   | otherwise = []


  -- go through all ELF symbol tables
  -- each symbol table entry that has as type STTObject with binding /= Local is considered external and that is not hidden
  -- its value is the address at which a relocation happens
  symbols_from_ELF_symbol_tables = concatMap mk_symbol_entry $ concat $ parseSymbolTables elf

  mk_symbol_entry sym_entry
    --   | is_external_var_symbol_entry sym_entry = [(fromIntegral $ steValue sym_entry, Relocated_Label $ get_string_from_steName $ steName sym_entry)]
    | is_internal_symbol_entry sym_entry     = [(fromIntegral $ steValue sym_entry, AddressOfLabel (get_string_from_steName $ steName sym_entry) False)]
    | otherwise = []


  -- external_variables = map mk_symbol_entry $ filter is_external_var_symbol_entry $ concat $ parseSymbolTables elf
  is_external_var_symbol_entry sym_entry = steType sym_entry `elem` [STTObject,STTCommon] && steBind sym_entry `elem` [STBGlobal, STBWeak] && not (isHiddenSymEntry sym_entry)
  
  is_internal_symbol_entry sym_entry = or
    [ steEnclosingSection sym_entry /= Nothing && steType sym_entry `notElem` [STTObject,STTCommon]
    , is_hidden sym_entry ]


  get_name_and_inex_from_reloc sec reloc =
    let sym_entry     = (elfRelSectSymbolTable sec) !! (fromIntegral $ elfRelSymbol reloc) in
      get_name_and_inex_from_sym_entry sym_entry

  get_name_and_inex_from_sym_entry sym_entry =
    let name          = get_string_from_steName $ steName sym_entry
        where_defined = steIndex sym_entry
        is_external   = case where_defined of
                          SHNUndef   -> True
                          SHNIndex _ -> False
    in
      (name,is_external)

  get_symbol_type_of_reloc sec reloc = steType $ (elfRelSectSymbolTable sec) !! (fromIntegral $ elfRelSymbol reloc)

  isHiddenSymEntry sym_entry = steOther sym_entry .&. 0x3 == 0x2
  is_hidden sym_entry = steType sym_entry `elem` [STTObject,STTCommon] && steBind sym_entry `elem` [STBGlobal, STBWeak] && isHiddenSymEntry sym_entry

  

-- get the name from a symbol table entry
get_string_from_steName (_, Just name) = T.unpack $ T.decodeUtf8 name
get_string_from_steName _ = ""

elf_min_address elf = minimum $ map elfSectionAddr $ filter isRelevantElfSection $ elfSections elf

elf_max_address elf = maximum $ map get_max_address $ filter isRelevantElfSection $ elfSections elf
 where
  get_max_address section = elfSectionAddr section + elfSectionSize section - 1


elf_read_file = parseElf


pp_elf_section section = "[" ++ intercalate ", " [elfSectionName section, show $ elfSectionType section, showHex (elfSectionAddr section), showHex (elfSectionSize section), showHex (elfSectionAddrAlign section)] ++ "]" 
pp_elf elf = intercalate "\n" $ pp_sections ++ pp_boundaries ++ pp_symbols ++ pp_relocs ++ pp_all_relocs ++ pp_all_symbols ++ pp_entry
 where
  pp_sections = map pp_elf_section $ elfSections elf
  pp_boundaries = ["Address range: " ++ showHex (elf_min_address elf) ++ " --> " ++ showHex (elf_max_address elf)]
  pp_symbols = ["Symbol table:\n" ++ show (elf_get_symbol_table elf)] 
  pp_relocs = ["Relocations:\n" ++ show (elf_get_relocs elf)] 


  pp_all_relocs  = "Complete relocation list:" : map show (concatMap elfRelSectRelocations $ parseRelocations elf)
  pp_all_symbols = "Complete symbol table:" : map show_symbol_entry (zip [0..] $ concat $ parseSymbolTables elf)
  show_symbol_entry (ind,sym_entry) = intercalate "; " [ show ind, show (steName sym_entry), show (steType sym_entry) , showHex (steValue sym_entry), show $ steIndex sym_entry, show $ steBind sym_entry ]


  pp_entry = ["Entry: " ++ (showHex $ elfEntry elf)]
  

elf_get_sections_info elf = SectionsInfo (map mk_section_info $ filter isRelevantElfSection $ elfSections elf) (elf_min_address elf) (elf_max_address elf)
 where
  mk_section_info section = ("",elfSectionName section,elfSectionAddr section,elfSectionSize section, elfSectionAddrAlign section)



elf_text_section_size = sum . map (fromIntegral . elfSectionSize) . filter isTextSection . elfSections
 where
  isTextSection sec = ("",elfSectionName sec) `elem` sections_text

instance BinaryClass Elf 
  where
    binary_read_ro_data = elf_read_ro_data
    binary_read_data = elf_read_data
    binary_get_sections_info = elf_get_sections_info
    binary_get_symbols = elf_get_symbol_table
    binary_get_relocations = elf_get_relocs
    binary_pp = pp_elf
    binary_entry = elfEntry
    binary_text_section_size = elf_text_section_size

