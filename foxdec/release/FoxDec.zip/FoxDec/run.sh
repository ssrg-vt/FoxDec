#!/bin/bash

entry_file_created=true

mkdir ./examples/$1
cp /binary/$1 ./examples/$1/$1
cd ./examples/$1
if [ -f "/binary/$1.entry" ]; then
  entry_file_created=false
  echo "Using $1.entry file for entry points."
  cp /binary/$1.entry .
else
  ../../scripts/get_elf_entry.sh $1 $1
fi
cd ../../
cabal run foxdec-exe -- -c ./config/config.dhall -d examples/$1/ -n $1 -i BINARY --Gmetrics --Gjson
cp -r examples/$1/* /artifacts/
if "$entry_file_created" ; then
  cp /artifacts/$1.entry /binary/$1.entry
  echo "File ./binary/$1.entry has been created, and may need to be updated manually with dangling function pointers."
fi
echo "Directory ./artifacts/ has been populated."
