#!/bin/bash

mkdir ./examples/$1
cp /binary/$1 ./examples/$1/$1
cabal run foxdec-exe -- -c ./config/config.dhall -d examples/$1/ -n $1 -i BINARY --Gmetrics --Gcallgraph --Gfuncs --GNASM
cp -r examples/$1/* /artifacts/
