#!/bin/bash


if [[ $# -ne 1 ]] || [ ! -f "./binary/$1" ] ; then
  echo "Usage: "
  echo "./foxdec.sh NAME"
  echo ""
  echo "  BINARY == binary under investigation, this file should be located in ./binary"
  echo ""
  echo "Example usage:"
  echo "  cp /usr/bin/wc ./binary/wc"
  echo "  ./foxdec.sh wc"
  echo ""
  echo "See README for more information."
  exit 1
fi

docker build -t foxdec .
docker run --rm --volume="$(pwd)/artifacts/:/artifacts" --volume="$(pwd)/binary/:/binary" -it foxdec $1
