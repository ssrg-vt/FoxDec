#ifndef __GRADER_EVAL_H__
#define __GRADER_EVAL_H__

#include "ast.h"

float evaluate(Expr expr);

#endif